const AppError = require("../utils/AppError");

function restrictTo(...allowedRoles) {
  return (req, res, next) => {
    if (!allowedRoles.includes(req.user.role)) {
      return next(new AppError("Kamu tidak memiliki izin untuk melakukan aksi ini", 403));
    }
    next();
  };
}

module.exports = restrictTo;